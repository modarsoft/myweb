from django.db import models
class Investment(models.Model):
    
    image=models.ImageField(upload_to="media/",blank=True,null=True)
    info=models.CharField(max_length=255,default="")
    active=models.BooleanField(default=False)
    
    cost=models.DecimalField(max_digits=8,decimal_places=0,default=0)
    code=models.CharField(max_length=8,default="")
    status=models.CharField(max_length=50)
    def __str__(self) :
        return self.info
    
class News(models.Model):
    news=models.CharField(max_length=255, default="")
    def __str__(self) :
        return self.news