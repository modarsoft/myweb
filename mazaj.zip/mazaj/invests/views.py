from django.shortcuts import render
from .models import Investment,News
from django.http import HttpResponse
# Create your views here.
def index(request):
    invest=Investment.objects.all()
    news=News.objects.all()
    return render(request,'index1.html',{'invest':invest , 'news':news})
    