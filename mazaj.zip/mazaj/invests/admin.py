from django.contrib import admin
from .models import Investment,News

admin.site.register(Investment)
admin.site.register(News)