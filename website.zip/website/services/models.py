

from django.db import models
from django.contrib.auth.models import User



class Maingroup(models.Model):
    group_name=models.CharField(max_length=50)
    group_image=models.ImageField(upload_to="Groupimages/",blank=True,null=True)
    def __str__(self) :
        return self.group_name
# Create your models here.

class Service_company(models.Model):
    service_company_name=models.CharField(max_length=50)
    service_group=models.ForeignKey(Maingroup, on_delete=models.CASCADE)
    service_company_image=models.ImageField(upload_to="companyimages/",blank=True,null=True)
    percent_cost=models.FloatField(default=0.05)
    def __str__(self) :
        return self.service_company_name



class Service(models.Model):
    service_name=models.CharField(max_length=50)
    service_company=models.ForeignKey(Service_company,  on_delete=models.CASCADE)
    service_cost=models.FloatField()
    service_price=models.FloatField()
    percent_cost=models.FloatField(default=0.05)
    service_image=models.ImageField(upload_to="images/",blank=True,null=True)

    def __str__(self) :
        return  "{}__{}".format(self.service_name,self.service_company.service_company_name) 

class Paybill(models.Model):
    user_bill=models.ForeignKey(User,on_delete=models.CASCADE)
    manager_execuser=models.CharField(max_length=30 ,default="-")
    service_bill=models.CharField(max_length=50)
    price_bill=models.FloatField()
    profit_bill=models.FloatField(default=0)
    user_balance_before=models.FloatField(default=0)
    user_balance=models.FloatField()
    date_bill=models.DateTimeField(auto_now_add=True)
    status_bill=models.CharField(max_length=50,default='انتظار')
    info=models.CharField(max_length=50, default="")

    def __str__(self):
        return self.user_bill.username + "--" + self.service_bill + "--" + self.status_bill


class Giga_Puckets(models.Model):
    pucket_name=models.CharField(max_length=10)
    pucket_cost=models.FloatField()
    pucket_price=models.FloatField()

    def __str__(self):
        return self.pucket_name + " : " + str(self.pucket_price)

class Net_providers(models.Model):
    provider_name=models.CharField(max_length=25)
    provider_image=models.ImageField(upload_to="images/",blank=True,null=True)
    provider_url=models.URLField(blank=True,null=True)
    def __str__(self):
        return self.provider_name

class Net_bill(models.Model):
    provider_name=models.ForeignKey(Net_providers,on_delete=models.CASCADE)
    net_name=models.CharField(max_length=10)
    net_cost=models.FloatField()
    net_price=models.FloatField()
    def __str__(self):
        return self.provider_name.provider_name + "----" + self.net_name
    
class GeneralReport(models.Model):
    manager=models.CharField(max_length=25)
    logins_date=models.DateTimeField(auto_now_add=True)
    report=models.CharField(max_length=100)

    def __str__(self):
          return self.report + "--" + self.manager + "--" + str(self.logins_date)
    

