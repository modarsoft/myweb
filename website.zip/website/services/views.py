
from unicodedata import decimal
from datetime import datetime, timedelta
from django.shortcuts import render,redirect
from django.urls import reverse
from pip import main
from django.contrib import messages
from django.db.models import Sum
import services
from .models import Investment, Net_bill, Net_providers, Service,Maingroup,Service_company,Paybill,Giga_Puckets,GeneralReport,Krminvest
from users.models import Usermoney
# Create your views here.
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
@login_required
def showServices(request):
    svs1=Maingroup.objects.all()
    return render(request,"services/showservices.html",{'svs':svs1})


#-----------------------------------------------------------------------------------
@login_required
def showServicesCompany(request,id):
    svscom=Service_company.objects.filter(service_group_id=id)
    return render(request,"services/showservicescompany.html",{'svs':svscom})
#-----------------------------------------------------------------------------------
@login_required
def showServicesInCompany(request,id):
    svscom=Service.objects.filter(service_company_id=id)
    return render(request,"services/showservicesincompany.html",{'svs':svscom})
#-----------------------------------------------------------------------------------
@login_required
def payforinternet(request):
    f=""
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    if request.method=="GET":
        if 'sizebucket' in request.GET:
           net_bills=Net_bill.objects.filter(net_name__contains=request.GET['sizebucket'])
           netproviders=Net_providers.objects.all()
      
           f={'check_money':check_money,'net_bills':net_bills,'net_prov':netproviders}
        else:
           
           f={'check_money':check_money,'noGet':'true'}
       
    
    
    
    return render(request,"services/payforinternetservice.html",f)
    #-----------------------------------------------------------------------------------

@login_required
def payforgroundphone(request,id):
    
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    
    return render(request,"services/payforgroundphone.html",{'svs':svscom ,'check_money':check_money})
    #-----------------------------------------------------------------------------------
@login_required
def savepaybills(request):    
    if request.method == 'POST':
        netcost=Net_bill.objects.get(provider_name__provider_name__iexact=request.POST['net_prov'].strip(),net_price=float(request.POST['net_price'])).net_cost

        svscom=  '%s____%s____%s____%s____%s ' % ("فاتورة انترنت",request.POST['net_prov'],request.POST['net_speed'] ,request.POST['city'],request.POST['phone'] )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if  float(request.POST['net_price']) >check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            sizebucket=request.POST['net_speed']
            return redirect(reverse('payforinternet'))

        else:
           bill=Paybill(user_bill=request.user,service_bill=svscom,cost_bill=netcost,price_bill=float(request.POST['net_price']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
           bill.save()
            
           
    return redirect('userorders')
#-----------------------------------------------------------------------------------

@login_required
def userorders(request):
    orders=Paybill.objects.filter(user_bill=request.user)
    return render(request,'services/paybills.html',{'orders':orders})

 #-----------------------------------------------------------------------------------   

@login_required
def chargeinternetbalance(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    netproviders=Net_providers.objects.all()
    
    return render(request,"services/chargeinternetbalance.html",{'svs':svscom ,'check_money':check_money,'net_prov':netproviders})
    


@login_required
def savepayforchargeinternetbalance(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____%s____%s____%s____%s ' % (svs.service_company_name ,request.POST['netProvider'],request.POST['city'],request.POST['phone'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeinternetbalance',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#-----------------------------------------------------------------------------------
@login_required
def chargegigabucket(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    buckets=Giga_Puckets.objects.all()
    netproviders=Net_providers.objects.all()
    
    
    return render(request,"services/chargegigabucket.html",{'svs':svscom ,'check_money':check_money,'buckets':buckets,'net_prov':netproviders})



@login_required
def savepayforchargegigabucket(request,id):
    
    if request.method == 'POST':
        svs=Service_company.objects.get(id=id)
        netcost=Giga_Puckets.objects.get(pucket_name__iexact=request.POST['bucket_size'].strip()).pucket_cost
        svscom=  '%s____%s____%s____%s____%s ' % (svs.service_company_name ,request.POST['netProvider'],request.POST['city'],request.POST['phone'],request.POST['bucket_size'] )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargegigabucket',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),cost_bill=netcost,profit_bill=0,user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#-----------------------------------------------------------------------------------
@login_required
def orders(request):
    orders=Paybill.objects.all()
    return render(request,'managment/orders.html',{'orders':orders})
#-----------------------------------------------------------------------------------
@login_required
def prepareexecuteorder(request,id):
    if request.user.is_superuser or request.user.is_staff:
       order=Paybill.objects.get(id=id)
       user_money=Usermoney.objects.get(user_name__id=order.user_bill.id)
    return render(request,'managment/prepareexecuteorder.html',{'order':order,'user_money':user_money})
#-----------------------------------------------------------------------------------
@login_required
def executeordersuccess(request,id):
    if request.user.is_superuser or request.user.is_staff:
       order=Paybill.objects.get(id=id)
       check_money=Usermoney.objects.get(user_name__id=order.user_bill.id)
       order.user_balance_before=check_money.user_money
       new_money=check_money.user_money-order.price_bill
       if(new_money<0):
          messages.warning(request,"لايوجد رصيد كافي")
          return redirect(reverse('prepareexecuteorder',kwargs={'id':id}))
       if (order.status_bill=="منفذ"):
          messages.warning(request,"تم تنفيذ الطلب من قبل مدير آخر")
          return redirect(reverse('prepareexecuteorder',kwargs={'id':id}))
       check_money.user_money=new_money
       check_money.save()
       order.user_balance=check_money.user_money
       order.status_bill="منفذ"
       order.manager_execuser=request.user.username
       order.save()
    return redirect('orders')
#-----------------------------------------------------------------------------------
@login_required
def executeorderfail(request,id):
    if request.user.is_superuser or request.user.is_staff:
        order=Paybill.objects.get(id=id)
    
        order.status_bill="فشل"
        order.info=request.GET['error_message']
        order.save()
    return redirect('orders')
#-----------------------------------------------------------------------------------
@login_required
def chargeallbalancesyriatel(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargeallbalancesyriatel.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargeallbalancesyriatel(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم الكود(%s)____%s____%s' % (svs.service_name ,request.POST['syriatel_code'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancesyriatel',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------------
@login_required
def usermoneyreport(request):
    report=Paybill.objects.filter(user_bill=request.user,status_bill='منفذ')
    return render(request,"services/usermoneyreport.html",{'orders':report})
#---------------------------------------------------------------------------
@login_required
def addbalancetouser(request):
    users=User.objects.all()
    return render(request,"services/addbalancetouser.html",{'users':users})

#---------------------------------------------------------------------------
@login_required
def saveaddbalancetouser(request):
    if "user_selected" in request.POST:
        user=Usermoney.objects.get(user_name__id=request.POST['user_selected'])
        user.user_money=float(user.user_money) + float(request.POST['added_money'])
        
        bill=Paybill(user_bill=user.user_name,service_bill="تم اضافة رصيد " +  request.POST['added_money'] + "ل.س",price_bill=0,profit_bill=0,user_balance_before= Usermoney.objects.get(user_name__id=user.user_name.id).user_money,user_balance=user.user_money,status_bill="منفذ")
        user.save()
        bill.save()
        general_log=GeneralReport(manager=request.user.username,report="تم إضافة رصيد " + request.POST['added_money'] + " للمستخدم " + user.user_name.username)
        general_log.save()
        messages.success(request," تم إضافة الرصيد بنجاح ل " + user.user_name.username + "\n" + "الرصيد الحالي :" + str(user.user_money) + "ل.س")
        
    return redirect(reverse('addbalancetouser'))

#-----------------------------------------------------------------------------------
@login_required
def chargeallbalancemtn(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargeallbalancemtn.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargeallbalancemtn(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم الكود(%s)____رقم الموبايل(%s)____%s' % (svs.service_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancemtn',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def chargebillsallbalancemtn(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargebillsallbalancemtn.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargebillsallbalancemtn(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____كود(%s)____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancemtn',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelbills(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/syriatelbills.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforsyriatelbills(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['syriatel_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelbills',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtnbills(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/syriatelbills.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayformtnbills(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtnbills',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelsumcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/syriatelsumcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforsyriatelsumcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رمز الموزع(%s)____%s____%s ' % (svs.service_company_name ,request.POST['giver_code'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelsumcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/syriatelcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforsyriatelcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['syriatel_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtnsumcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/mtnsumcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayformtnsumcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الكود(%s)____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtnsumcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtncash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/mtncash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayformtncash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtncash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
from django.http import JsonResponse
from django.core import serializers
def getbalance(request):
    
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    return render(request,'index.html',{'money':check_money})
    
def subject_renderer(request):
    check_money="0"
    if request.user.is_authenticated:
       if Usermoney.objects.all().count()>0:

          check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    return {
          'moneyus':check_money,
                }

#-----------------------------------------------------------------------------------
@login_required
def groundphonebill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/groundphonebill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforgroundphonebill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        if "mobile_number" in request.POST:
            svscom=  '%s____رقم الأرضي(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['ground_phone_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        else:
            svscom=  '%s____رقم الأرضي(%s)____%s____%s ' % (svs.service_company_name ,request.POST['ground_phone_number'],request.POST['city'],request.POST['added_money']+"ل.س" )

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('groundphonebill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def electrisitybill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/electrisitybill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforelectrisitybill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
       
        svscom=  '%s____الرقم الخاص(%s)____رقم الاشتراك(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['spesial_number'],request.POST['contract_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('electrisitybill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#---------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def waterbill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/waterbill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforwaterbill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
       
        svscom=  '%s____رقم الباركود(%s)____رقم العداد(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['barcode_number'],request.POST['counter_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('waterbill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#---------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelbalanceone(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/syriatelbalanceone.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforsyriatelbalanceone(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['syriatel_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelbalanceone',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtnbalanceone(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/mtnbalanceone.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayformtnbalanceone(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtnbalanceone',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
    #-----------------------------------------------------------------------------------
    #-----------------------------------------------------------------------------------
@login_required
def investment(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    
    return render(request,"services/investment.html",{'svs':svscom ,'check_money':check_money})
from django.core.files.storage import FileSystemStorage
@login_required
def invest(request):
    if request.POST:
        upload = request.FILES['invest_file']
        
        myinvest=Investment(user=request.user,image=upload,active=False,expire=request.POST['number_days'],cost=request.POST['final_cost'])
        myinvest.save()
    

    return redirect('myinvestments')
@login_required
def deleteinvest(request,id):
    d=Investment.objects.get(id=id)
    d.delete()
    return redirect('myinvestments')

@login_required
def deleteinvestfrommanage(request,id):
    d=Investment.objects.get(id=id)
    d.delete()
    return redirect('investmanage')

@login_required
def payforinvestment(request,id):
       
        invest=Investment.objects.get(id=id)
        
      
        check_money=Usermoney.objects.get(user_name__id=invest.user.id)
        if float(invest.cost)>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('investmanage'))
        else:
            invest.active=True
            invest.start_date=datetime.now()
            invest.end_date=invest.start_date + timedelta(days=invest.expire)
            invest.save()
            bill=Paybill(user_bill=invest.user,service_bill="خدمة الإعلان",price_bill=float(invest.cost),profit_bill=0,user_balance= Usermoney.objects.get(user_name__id=invest.user.id).user_money,status_bill="منفذ")
            bill.save()  
            if request.user.is_superuser or request.user.is_staff:
               order=Paybill.objects.last()
               check_money=Usermoney.objects.get(user_name__id=invest.user.id)
               order.user_balance_before=check_money.user_money
               new_money=check_money.user_money-order.price_bill
               if(new_money<0):
                  messages.warning(request,"لايوجد رصيد كافي")
                  return redirect(reverse('investmanage'))
               
               check_money.user_money=new_money
               check_money.save()
               order.user_balance=check_money.user_money
               
               order.manager_execuser=request.user.username
               order.save()
        return redirect('investmanage')

@login_required
def investmanage(request):
    invest=Investment.objects.all()
    return render(request,'services/investmanage.html',{'invest':invest})

@login_required
def myinvestments(request):
    invest=Investment.objects.filter(user=request.user)
    return render(request,'services/myinvestments.html',{'invest':invest})
@login_required
def refuse(request,id):
    invest11=Investment.objects.get(id=id)
    invest11.status="مرفوض"
    
    invest11.save()
    return redirect('investmanage')

    #-----------------------------------------------------------------------------------
@login_required   
def datedreport(request):
    return render(request,'managment/reportdate.html')
@login_required
def showdatedreport(request):
    
    if request.GET:
        alluser=User.objects.all().count()
        allbalances=Usermoney.objects.aggregate(Sum('user_money'))['user_money__sum']
        orders_count=Paybill.objects.filter(date_bill__range=(request.GET['from_date'],request.GET['to_date'])).count()
        order_execused_count=Paybill.objects.filter(date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='منفذ').count()
        orders_not_execused_count=Paybill.objects.filter(date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='انتظار').count()
        orders_failed_count=Paybill.objects.filter(date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='فشل').count()
        profits=Paybill.objects.filter(date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='منفذ').aggregate(Sum('profit_bill'))['profit_bill__sum']
        profits_from_fixed_all1=Paybill.objects.filter(service_bill__icontains=('شحن باقة'),date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='منفذ')
        profits_from_fixed_all2=Paybill.objects.filter(service_bill__icontains=('فاتورة انترنت'),date_bill__range=(request.GET['from_date'],request.GET['to_date']),status_bill='منفذ')
        
        profits_from_fixed_1=profits_from_fixed_all1.aggregate(Sum('price_bill'))['price_bill__sum']
        profits_from_fixed_2=profits_from_fixed_all1.aggregate(Sum('cost_bill'))['cost_bill__sum']
        profits_from_fixed_3=profits_from_fixed_all2.aggregate(Sum('price_bill'))['price_bill__sum']
        profits_from_fixed_4=profits_from_fixed_all2.aggregate(Sum('cost_bill'))['cost_bill__sum']
        if not profits_from_fixed_1:
            profits_from_fixed_1=0
        if not profits_from_fixed_2:
            profits_from_fixed_2=0
        if not profits_from_fixed_3:
            profits_from_fixed_3=0
        if not profits_from_fixed_4:
            profits_from_fixed_4=0
        profits_from_investments=Paybill.objects.filter(service_bill__contains="خدمة الإعلان",date_bill__range=(request.GET['from_date'],request.GET['to_date'])).aggregate(Sum('price_bill'))['price_bill__sum']
        sumprofits=(profits_from_fixed_3 - profits_from_fixed_4 )+(profits_from_fixed_1 - profits_from_fixed_2 )


    return render(request,'managment/showdatedreport.html',{'from_date':request.GET['from_date'],'to_date':request.GET['to_date'],'alluser':alluser,'allbalances':round(allbalances,2),'orders_count':orders_count,'order_execused_count':order_execused_count,'orders_not_execused_count':orders_not_execused_count,'orders_failed_count': orders_failed_count,'profits':profits,'profits_from_fixed':sumprofits,'profits_from_investments':profits_from_investments})
     
#-------------------------------------------------------------
def krminvest(request):
    

    return render(request,"services/krminvest.html",{})

def savekrminvest(request):
    if request.POST:
        krminvestment=Krminvest.objects.all()
        if krminvestment.count()>0:
           ff=Krminvest.objects.get(id=1)
           ff.image=request.FILES['invest_file']
           ff.save()
            
            
        else:
            krminvestment=Krminvest(image=request.FILES['invest_file'])
            krminvestment.save()


           


    return redirect('index')