from curses import pair_content
from tabnanny import check
from django.shortcuts import render,redirect
from django.urls import reverse
from pip import main
from django.contrib import messages
import services
from .models import Net_bill, Net_providers, Service,Maingroup,Service_company,Paybill,Giga_Puckets,GeneralReport
from users.models import Usermoney
# Create your views here.
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
@login_required
def showServices(request):
    svs1=Maingroup.objects.all()
    return render(request,"services/showservices.html",{'svs':svs1})


#-----------------------------------------------------------------------------------
@login_required
def showServicesCompany(request,id):
    svscom=Service_company.objects.filter(service_group_id=id)
    return render(request,"services/showservicescompany.html",{'svs':svscom})
#-----------------------------------------------------------------------------------
@login_required
def showServicesInCompany(request,id):
    svscom=Service.objects.filter(service_company_id=id)
    return render(request,"services/showservicesincompany.html",{'svs':svscom})
#-----------------------------------------------------------------------------------
@login_required
def payforinternet(request):
    f=""
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    if request.method=="GET":
        if 'sizebucket' in request.GET:
           net_bills=Net_bill.objects.filter(net_name__contains=request.GET['sizebucket'])
      
           f={'check_money':check_money,'net_bills':net_bills}
        else:
           
           f={'check_money':check_money,'noGet':'true'}
       
    
    #-----------------------------------------------------------------------------------
    
    return render(request,"services/payforinternetservice.html",f)
@login_required
def payforgroundphone(request,id):
    
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    
    return render(request,"services/payforgroundphone.html",{'svs':svscom ,'check_money':check_money})
    #-----------------------------------------------------------------------------------
@login_required
def savepaybills(request):    
    if request.method == 'POST':
        
        svscom=  '%s____%s____%s____%s____%s ' % ("فاتورة انترنت",request.POST['net_prov'],request.POST['net_speed'] ,request.POST['city'],request.POST['phone'] )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if  float(request.POST['net_price']) >check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            sizebucket=request.POST['net_speed']
            return redirect(reverse('payforinternet'))

        else:
           bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['net_price']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
           bill.save()
            
           
    return redirect('userorders')
#-----------------------------------------------------------------------------------

@login_required
def userorders(request):
    orders=Paybill.objects.filter(user_bill=request.user)
    return render(request,'services/paybills.html',{'orders':orders})

 #-----------------------------------------------------------------------------------   

@login_required
def chargeinternetbalance(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    netproviders=Net_providers.objects.all()
    
    return render(request,"services/chargeinternetbalance.html",{'svs':svscom ,'check_money':check_money,'net_prov':netproviders})
    


@login_required
def savepayforchargeinternetbalance(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____%s____%s____%s____%s ' % (svs.service_company_name ,request.POST['netProvider'],request.POST['city'],request.POST['phone'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeinternetbalance',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#-----------------------------------------------------------------------------------
@login_required
def chargegigabucket(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    buckets=Giga_Puckets.objects.all()
    netproviders=Net_providers.objects.all()
    
    
    return render(request,"services/chargegigabucket.html",{'svs':svscom ,'check_money':check_money,'buckets':buckets,'net_prov':netproviders})



@login_required
def savepayforchargegigabucket(request,id):
    
    if request.method == 'POST':
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____%s____%s____%s____%s ' % (svs.service_company_name ,request.POST['netProvider'],request.POST['city'],request.POST['phone'],request.POST['bucket_size'] )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargegigabucket',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=0,user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#-----------------------------------------------------------------------------------
@login_required
def orders(request):
    orders=Paybill.objects.all()
    return render(request,'managment/orders.html',{'orders':orders})
#-----------------------------------------------------------------------------------
@login_required
def prepareexecuteorder(request,id):
    if request.user.is_superuser or request.user.is_staff:
       order=Paybill.objects.get(id=id)
       user_money=Usermoney.objects.get(user_name__id=order.user_bill.id)
    return render(request,'managment/prepareexecuteorder.html',{'order':order,'user_money':user_money})
#-----------------------------------------------------------------------------------
@login_required
def executeordersuccess(request,id):
    if request.user.is_superuser or request.user.is_staff:
       order=Paybill.objects.get(id=id)
       check_money=Usermoney.objects.get(user_name__id=order.user_bill.id)
       order.user_balance_before=check_money.user_money
       new_money=check_money.user_money-order.price_bill
       if(new_money<0):
          messages.warning(request,"لايوجد رصيد كافي")
          return redirect(reverse('prepareexecuteorder',kwargs={'id':id}))
       if (order.status_bill=="منفذ"):
          messages.warning(request,"تم تنفيذ الطلب من قبل مدير آخر")
          return redirect(reverse('prepareexecuteorder',kwargs={'id':id}))
       check_money.user_money=new_money
       check_money.save()
       order.user_balance=check_money.user_money
       order.status_bill="منفذ"
       order.manager_execuser=request.user.username
       order.save()
    return redirect('orders')
#-----------------------------------------------------------------------------------
@login_required
def executeorderfail(request,id):
    if request.user.is_superuser or request.user.is_staff:
        order=Paybill.objects.get(id=id)
    
        order.status_bill="فشل"
        order.info=request.GET['error_message']
        order.save()
    return redirect('orders')
#-----------------------------------------------------------------------------------
@login_required
def chargeallbalancesyriatel(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargeallbalancesyriatel.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargeallbalancesyriatel(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____code(%s)____%s____%s' % (svs.service_name ,request.POST['syriatel_code'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancesyriatel',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------------
@login_required
def usermoneyreport(request):
    report=Paybill.objects.filter(user_bill=request.user,status_bill='منفذ')
    return render(request,"services/usermoneyreport.html",{'orders':report})
#---------------------------------------------------------------------------
@login_required
def addbalancetouser(request):
    users=User.objects.all()
    return render(request,"services/addbalancetouser.html",{'users':users})

#---------------------------------------------------------------------------
@login_required
def saveaddbalancetouser(request):
    if "user_selected" in request.POST:
        user=Usermoney.objects.get(user_name__id=request.POST['user_selected'])
        user.user_money=user.user_money + float(request.POST['added_money'])
        
        bill=Paybill(user_bill=user.user_name,service_bill="تم اضافة رصيد " +  request.POST['added_money'] + "ل.س",price_bill=0,profit_bill=0,user_balance_before= Usermoney.objects.get(user_name__id=user.user_name.id).user_money,user_balance=user.user_money,status_bill="منفذ")
        user.save()
        bill.save()
        general_log=GeneralReport(manager=request.user.username,report="تم إضافة رصيد " + request.POST['added_money'] + " للمستخدم " + user.user_name.username)
        general_log.save()
        messages.success(request," تم إضافة الرصيد بنجاح ل " + user.user_name.username + "\n" + "الرصيد الحالي :" + str(user.user_money) + "ل.س")
        
    return redirect(reverse('addbalancetouser'))

#-----------------------------------------------------------------------------------
@login_required
def chargeallbalancemtn(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargeallbalancemtn.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargeallbalancemtn(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____code(%s)____mobile(%s)____%s____%s' % (svs.service_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancemtn',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def chargebillsallbalancemtn(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/chargebillsallbalancemtn.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforchargebillsallbalancemtn(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____كود(%s)____رقم موبايل(%s)____%s____%s' % (svs.service_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('chargeallbalancemtn',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelbills(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/syriatelbills.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayforsyriatelbills(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['syriatel_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelbills',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#---------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtnbills(request,id):
    svscom=Service.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money  
    return render(request,"services/syriatelbills.html",{'svs':svscom ,'check_money':check_money})

@login_required
def savepayformtnbills(request,id):
    if request.method == 'POST':    
        svs=Service.objects.get(id=id)
        svscom=  '%s____رقم موبايل(%s)____%s' % (svs.service_name ,request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtnbills',args=[id]))
        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()          
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelsumcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/syriatelsumcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforsyriatelsumcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رمز الموزع(%s)____%s____%s ' % (svs.service_company_name ,request.POST['giver_code'],request.POST['city'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelsumcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def syriatelcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/syriatelcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforsyriatelcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['syriatel_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('syriatelcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtnsumcash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/mtnsumcash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayformtnsumcash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الكود(%s)____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['mtn_code'],request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtnsumcash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def mtncash(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/mtncash.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayformtncash(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        svscom=  '%s____رقم الموبايل(%s)____%s ' % (svs.service_company_name ,request.POST['mtn_mobile'],request.POST['added_money']+"ل.س" )
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('mtncash',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
from django.http import JsonResponse
from django.core import serializers
def getbalance(request):
    
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    return render(request,'index.html',{'money':check_money})
    
def subject_renderer(request):
    check_money="0"
    if request.user.is_authenticated:

       check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
    return {
          'moneyus':check_money,
                }

#-----------------------------------------------------------------------------------
@login_required
def groundphonebill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/groundphonebill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforgroundphonebill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
        if "mobile_number" in request.POST:
            svscom=  '%s____رقم الأرضي(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['ground_phone_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        else:
            svscom=  '%s____رقم الأرضي(%s)____%s____%s ' % (svs.service_company_name ,request.POST['ground_phone_number'],request.POST['city'],request.POST['added_money']+"ل.س" )

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('groundphonebill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def electrisitybill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/electrisitybill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforelectrisitybill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
       
        svscom=  '%s____الرقم الخاص(%s)____رقم الاشتراك(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['spesial_number'],request.POST['contract_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('electrisitybill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#---------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@login_required
def waterbill(request,id):

    svscom=Service_company.objects.get(id=id)
    check_money=Usermoney.objects.get(user_name__id=request.user.id).user_money
   
    
    return render(request,"services/waterbill.html",{'svs':svscom ,'check_money':check_money})
    


@login_required
def savepayforwaterbill(request,id):
    
    
    if request.method == 'POST':    
        svs=Service_company.objects.get(id=id)
       
        svscom=  '%s____رقم الباركود(%s)____رقم العداد(%s)____رقم الموبايل(%s)____%s____%s ' % (svs.service_company_name ,request.POST['barcode_number'],request.POST['counter_number'],request.POST['mobile_number'],request.POST['city'],request.POST['added_money']+"ل.س" )
        

        
        check_money=Usermoney.objects.get(user_name__id=request.user.id)
        if float(request.POST['final_cost'])>check_money.user_money:
            messages.warning(request,"لا يوجد رصيد كاف لاتمام الطلب")
            return redirect(reverse('waterbill',args=[id]))

        else:
            bill=Paybill(user_bill=request.user,service_bill=svscom,price_bill=float(request.POST['final_cost']),profit_bill=float(request.POST['final_cost'])-float(request.POST['added_money']),user_balance= Usermoney.objects.get(user_name__id=request.user.id).user_money)
            bill.save()
            
            
    return redirect('userorders')
#---------------------------------------------------------------------------------------------