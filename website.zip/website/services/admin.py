from django.contrib import admin
from .models import Service,Maingroup,Service_company,Paybill,Giga_Puckets,Net_providers,Net_bill,GeneralReport
# Register your models here.
admin.site.register(Service)
admin.site.register(Maingroup)
admin.site.register(Service_company)
admin.site.register(Paybill)
admin.site.register(Giga_Puckets)
admin.site.register(Net_providers)
admin.site.register(Net_bill)
admin.site.register(GeneralReport)