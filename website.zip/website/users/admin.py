from django.contrib import admin
from .models import Usermoney
# Register your models here.
admin.site.register(Usermoney)