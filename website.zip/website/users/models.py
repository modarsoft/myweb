from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Usermoney(models.Model):
    user_name=models.OneToOneField(User,on_delete=models.CASCADE)
    user_money=models.FloatField(default=0)

    def __str__(self):
        return self.user_name.username


