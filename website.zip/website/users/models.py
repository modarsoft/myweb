from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Usermoney(models.Model):
    user_name=models.OneToOneField(User,on_delete=models.CASCADE)
    user_money=models.DecimalField(max_digits=8, default=0,decimal_places=2)

    def __str__(self):
        return self.user_name.username


