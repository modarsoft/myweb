from operator import truediv
from datetime import datetime,timedelta
from django.shortcuts import render,redirect
from django.core.exceptions import ValidationError 
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from django.contrib.auth.models import User
from .models import Usermoney

from django.contrib import messages
from services.models import GeneralReport
from django.urls import reverse_lazy
from django.contrib.auth.views import PasswordResetView
from django.contrib.messages.views import SuccessMessageMixin
from services.models import Investment,Krminvest


# Create your views here.
@login_required    #صفحة ادخول الرئيسية
def index(request):
    krminvest1=Krminvest.objects.all()
    krminvest=Krminvest.objects.all()
    if krminvest.count()>0:
        krminvest1=Krminvest.objects.get(id=1)
    invest=Investment.objects.filter(end_date__gte=datetime.now())
    for i in invest:
        if i.status != "مرفوض":
           i.status="جاري الاعلان"
           i.save()
    invest1=Investment.objects.filter(end_date__lt=datetime.now())
    for i in invest1:
        if i.status != "مرفوض":
           i.status="انتهت مدة الاعلان"
           i.save()
    return render(request,'index.html',{'invest':invest,'krminvest':krminvest1})

#___________________________________________________________________________________
def authenticate(request):#من خلال هذه الوظيفة يتم تسجيل الدخول للموقع والتحويل للصفحة الرئيسية او صفحة تسجيل الدخول
    f=None
    if request.method == 'POST':
        
           
            
            user = auth.authenticate(
                username=request.POST['loginUser'],
                password=request.POST['loginPassword'],
            )
            if user is not None:
                general_log=GeneralReport(manager=request.POST['loginUser'],report="تم تسجيل الدخول ")
                general_log.save()
                auth.login(request, user)
                if "rememberme" not in request.POST:
                    request.session.set_expiry(0) 
                f='index'
            else:
                f='login'  

        

    return redirect(f)
#________________________________________________________________________________________
def gotoregister(request):
    
      
    return render(request,'users/register.html')

def register(request):  
    puser=True
    ppassword=True
    pemail=True
    f='register'
    if request.method == 'POST': 
        username=request.POST['uname'] 
        password1=request.POST['upass1']
        password2=request.POST['upass2']
        email=request.POST['uemail']
        new = User.objects.filter(username = username)  
        if new.count():
            puser=False  
            messages.error(request,"اسم المستخدم موجود")  
        new = User.objects.filter(email=email)  
        if new.count(): 
            pemail=False 
            messages.error(request," البريد الالكتروني موجود") 
        if password1 and password2 and password1 != password2:
            ppassword=False  
            messages.error(request,"كلمة المرور غير متطابقة")

        if puser and ppassword and pemail:
            user = User.objects.create_user(  
            username,  
            email,  
            password1)
           
            user.save()
            Usermoney(user_name=User.objects.get(username=username),user_money=0).save()
            f='users/messagetologin.html' 
          
        else:
            f='users/register.html' 
  
    return render(request,f,{'name':username,'pass':password1,'email':email}) 
#-------------------------------------------------------------------------------
def changepassword(request):
    return render(request,"users/changepassword.html")

def savechangepassword(request):
    
    puser=True
    ppassword=True
   
    
    if request.method == 'POST': 
        oldpassword=request.POST['oldpassword'] 
        password1=request.POST['upass1']
        password2=request.POST['upass2']
       
        
        if request.user.check_password(oldpassword)==False:
            
            puser=False  
            messages.error(request,"كلمة مرور المستخدم غير صحيحة")  
         
        if password1 and password2 and password1 != password2:
            ppassword=False  
            messages.error(request,"كلمة المرور الجديدة غير متطابقة")

        if puser and ppassword :
            user = User.objects.get(username=request.user.username)
            user.set_password(password1)
            user.save()
            messages.success(request,"تم تغيير كلمة المرور بنجاح")
            return render(request,"users/messagetologin.html",{'changepassword':'true'})
            
  
    return redirect('changepassword') 

#------------------------------------------------------------------------------------ 
class ResetPasswordView(SuccessMessageMixin, PasswordResetView):
    template_name = 'users/password_reset.html'
    email_template_name = 'users/password_reset_email.html'
    subject_template_name = 'users/password_reset_subject.txt'
    success_message = "We've emailed you instructions for setting your password, " \
                      "if an account exists with the email you entered. You should receive them shortly." \
                      " If you don't receive an email, " \
                      "please make sure you've entered the address you registered with, and check your spam folder."
    success_url = reverse_lazy('message_tologin_frompassword')

#---------------------------------------------------------------------------------
def messagetologinfrompassword(request):
    return render(request,'users/messagetologinfrompasswordreset.html')