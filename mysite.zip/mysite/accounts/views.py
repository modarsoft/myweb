import itertools
from django.shortcuts import render
from .models import Profile , Client_fond
from itertools import chain
# Create your views here.
def app(request):
    profile=Client_fond.objects.all()
  
    request.session['gg']={'k':profile[1].name.name,'l':1500}
    return render(request,'user/app.html',{})


def searchtext(request):
    
    
    return render(request,'user/search.html', {})

def showTable(request):
    profile=Client_fond.objects.all()
    dd=Profile.objects.all()
    request.session['gg']={'k':profile[0].name.name,'l':1500}
    return render(request,'user/showtable.html',{'pro':profile,'im':dd})

def showuserfond(request,id):
   
    getfond=Client_fond.objects.filter(name__id=id)
    
 
    return render(request,'user/showuserfond.html',{'userfond':getfond})