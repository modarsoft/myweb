from django.urls import path
from . import views


urlpatterns = [
   path('',views.app,name='app'),
   path('search/',views.searchtext,name='search'),
   path('showtable/',views.showTable,name='showtable'),
    path('showuserfond/<int:id>',views.showuserfond,name='showuserfond')
]