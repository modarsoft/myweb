from distutils.command.upload import upload
from unicodedata import name
from django.db import models


class Profile(models.Model):
    name=models.CharField(max_length=30)
    adress=models.CharField(max_length=30)
    date=models.DateTimeField(auto_now=True)
    img = models.ImageField(null=True, blank=True,upload_to="image/")
    
    def __str__(self):
        return self.name
    
    
class Client_fond(models.Model):
    name=models.ForeignKey(Profile,on_delete=models.CASCADE)
    fond=models.IntegerField()
    
    def __str__(self):
        return self.name.name + " : " + str(self.fond)
    
# Create your models here.
