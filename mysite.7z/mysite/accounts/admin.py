from django.contrib import admin
from .models import Profile , Client_fond
# Register your models here.

admin.site.register(Profile)
admin.site.register(Client_fond)
